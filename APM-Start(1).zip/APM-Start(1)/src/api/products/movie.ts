export interface IMovie{
    movieId:number;
    imageUrl:string;
    title:string;
    duration:string;
    review:string;
    city:string;
    rating:number;
    
}