import {Component, OnInit} from '@angular/core'
import { IProduct } from '../../api/products/product';
import { ProductService } from '../../api/products/product.service';

@Component({
   // selector:'pm-products',
    templateUrl:'./product-list.component.html',
    styles:['thead{color:#337AB7;}']
    
})
export class ProductListComponent implements OnInit
{
    pageTitle:string='Product List';
    imageWidth:number=60;
    imageMargin:number=2;
    showImage:boolean=false;
    errorMessage:string;
    _listFilter:string;
    filteredProducts:IProduct[];
    products:IProduct[]=[];
       constructor(private _productService:ProductService)
       {
        //this.filteredProducts=this.products
        this.listFilter='cart'
       }
    // constructor(){
    //     this.filteredProducts=this.products
    //     this.listFilter='cart'

    // }
    ngOnInit():void{
        // console.log('In OnInit')
        this._productService.getProducts().subscribe(products=> {
            this.products=products;
            this.filteredProducts=this.products
        },
        error=>this.errorMessage=<any>error
        );
       
        
    }
    onRatingClicked(messege:string):void{
        this.pageTitle='Product List :'+ messege;
    }
    get listFilter():string {
        return this._listFilter;

    }
    set listFilter(value:string)
    {
        this._listFilter=value;
        this.filteredProducts=this.listFilter?this.performFilter(this.listFilter):this.products;
    }
    

    performFilter(filterBy:string): IProduct[]
    {
        filterBy=filterBy.toLocaleLowerCase();
        return this.products.filter((product:IProduct)=>
        product.productName.toLocaleLowerCase().indexOf(filterBy)!==-1
        );
    }
    toggleImage():void{
        this.showImage=!this.showImage
    }
    
   
}