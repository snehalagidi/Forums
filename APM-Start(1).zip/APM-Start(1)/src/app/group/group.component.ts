import { Component, OnInit } from '@angular/core';
import { GroupsService } from '../../api/groups/groups.service';
import { IFriend } from '../../api/groups/friends';
import { IGroup } from '../../api/groups/groups';


@Component({
   selector: 'app-group', 
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
  //groups:IGroup;
   groups=  new IGroup();
  
  
  group:IGroup;
  friends:IFriend[]=[];

  errorMessage:string;

  public pageTitle: string='create';

    flag:boolean=false;
  showFriends:boolean=false;
  addFriends:boolean=false;
  message:string;
 groupId:number;
    onClick():void{
      this.flag=true;
    }
   

constructor(private _groupService:GroupsService) {

 }

 toggle(group:IGroup):void{
 
 group.groupAdmin=2;
      this._groupService.createGroup(group).subscribe(groups=>{
        
        console.log(groups);
      localStorage.setItem('groupInfo',JSON.stringify(groups));
   location.reload(true);
      this.groups=groups;

       
        
 },
 
 error=>this.errorMessage=<any>error
      );
  
    
} 
  ngOnInit() {
       console.log('In OnInit')

      this._groupService.getFriends().subscribe(friends=> {
        this.friends=friends;
       
        
 },
 
 error=>this.errorMessage=<any>error
      );
  
    
}
toggleImage():void{
  this.showFriends=!this.showFriends
}
toggleAdd():void{
  this.addFriends=!this.addFriends
}
}
